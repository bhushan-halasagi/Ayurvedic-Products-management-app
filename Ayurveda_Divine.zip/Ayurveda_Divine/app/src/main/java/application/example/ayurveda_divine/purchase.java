package application.example.ayurveda_divine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class purchase extends AppCompatActivity {


    public static TextView dateText;
    TextInputLayout city,customer,amount,medicine,shortWord;
    private String saveCurrentDate,saveCurrentTime,productRandomKey;
    Button upload;

    DatabaseReference databaseReference;

    private ProgressDialog mProgress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);

        dateText=(TextView)findViewById(R.id.dateTextView);
        mProgress= new ProgressDialog(this);

        medicine=(TextInputLayout) findViewById(R.id.medicine_name);
        shortWord=(TextInputLayout) findViewById(R.id.short_word);
        amount=(TextInputLayout) findViewById(R.id.amount);
        customer=(TextInputLayout) findViewById(R.id.customer_name);
        city=(TextInputLayout) findViewById(R.id.city);
        upload=(Button) findViewById(R.id.upload);


        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                String med=medicine.getEditText().getText().toString();
                String sword=shortWord.getEditText().getText().toString();
                String cit=city.getEditText().getText().toString();
                String amt=amount.getEditText().getText().toString();
                String cust=customer.getEditText().getText().toString();

                databaseReference=FirebaseDatabase.getInstance().getReference("Medicine");


                Medicine me=new Medicine(med,sword,amt,cit,cust);

                FirebaseDatabase.getInstance().getReference("Medicine")
                        .child(cust)
                        .setValue(me).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(purchase.this, "Data on Medicine Added", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    }
                });



            }
        });










    }

    public void btn_PickerDate(View view) {

        DialogFragment fragment = new MyDate();
        fragment.show(getSupportFragmentManager(),"Date Picker");

    }

    public static void populateSetDateText(int year,int month,int day){

        dateText.setText(month+"/"+day+"/"+year);
    }
}