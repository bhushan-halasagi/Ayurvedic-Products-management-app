package application.example.ayurveda_divine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class join extends AppCompatActivity {

    Button btn_Customer;
    Button  btn_Material;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        btn_Customer=(Button)findViewById(R.id.buttonCustomer);
        btn_Material=(Button)findViewById(R.id.buttonMedicine);

        btn_Customer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),home1.class));
            }
        });

        btn_Material.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),home.class));
            }
        });




    }






    public void btn_Customer(View view) {
        startActivity(new Intent(getApplicationContext(),home1.class));
    }

    public void btn_Material(View view) {
        startActivity(new Intent(getApplicationContext(),home.class));
    }
}
