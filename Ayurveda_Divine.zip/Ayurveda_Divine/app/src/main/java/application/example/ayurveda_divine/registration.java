package application.example.ayurveda_divine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class registration extends AppCompatActivity {

    EditText txtfullName;
    EditText txtEmail;
    EditText txtPassword;
    EditText txtConfirmPassword;
    Button btn_register;
    RadioButton radioGenderMale,radioGenderFemale;
    ProgressBar progressBar;
    String gender="";
    private FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        txtfullName=(EditText)findViewById(R.id.txt_fullName);
        txtEmail=(EditText)findViewById(R.id.txt_email);
        txtPassword=(EditText)findViewById(R.id.txt_password);
        txtConfirmPassword=(EditText)findViewById(R.id.txt_confirm_password);
        btn_register=(Button)findViewById(R.id.buttonRegister);
        radioGenderMale=(RadioButton)findViewById(R.id.radio_male);
        radioGenderFemale=(RadioButton)findViewById(R.id.radio_female);
        progressBar=(ProgressBar)findViewById(R.id.progressBar);

        firebaseAuth=FirebaseAuth.getInstance();
        databaseReference=FirebaseDatabase.getInstance().getReference("customer");


        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String fullName=txtfullName.getText().toString();
                String email= txtEmail.getText().toString();
                String password=txtPassword.getText().toString();
                String confirmpassword=txtConfirmPassword.getText().toString();

                if(radioGenderMale.isChecked()){

                    gender="Male";
                }

                if(radioGenderFemale.isChecked()){
                    gender="Female";
                }


                if(TextUtils.isEmpty(email)){
                    Toast.makeText(registration.this, "Please Enter Email", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(getApplicationContext(),registration.class));
                }

                if(TextUtils.isEmpty(password)){
                    Toast.makeText(registration.this, "Please Enter Password", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(getApplicationContext(),registration.class));
                }

                if(password.length()<8){
                    Toast.makeText(registration.this, "Password must at least 8 characters", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(getApplicationContext(),registration.class));
                }

                if(TextUtils.isEmpty(confirmpassword)){
                    Toast.makeText(registration.this, "Please Enter Confirm Password", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(getApplicationContext(),registration.class));
                }


                progressBar.setVisibility(View.VISIBLE);


                if(password.equals(confirmpassword)){




                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(registration.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    progressBar.setVisibility(View.GONE);

                                    if (task.isSuccessful()) {

                                        customer information=new customer(fullName,email,gender);

                                        FirebaseDatabase.getInstance().getReference("customer")
                                                .child(fullName)
                                                .setValue(information).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                                Toast.makeText(registration.this, "Registration Complete", Toast.LENGTH_LONG).show();
                                                startActivity(new Intent(getApplicationContext(),login.class));
                                            }
                                        });

                                    } else {
                                        Toast.makeText(registration.this, "Authentication Failed", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(getApplicationContext(),registration.class));

                                    }

                                    // ...
                                }
                            });

                }
                else
                {
                    Toast.makeText(registration.this, "Password and Confirm Password are different", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(getApplicationContext(),registration.class));
                }


            }
        });





    }
    public void btn_registration(View view) {
        startActivity(new Intent(getApplicationContext(),registration.class));
    }
    public void btn_login(View view) {
        startActivity(new Intent(getApplicationContext(),login.class));
    }
}