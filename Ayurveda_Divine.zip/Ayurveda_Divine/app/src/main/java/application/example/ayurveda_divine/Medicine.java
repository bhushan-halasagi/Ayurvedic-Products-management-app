package application.example.ayurveda_divine;

public class Medicine {

    private String amount;
    private String city;
    private String customer_name;
    private String medicine_name;
    private String short_word;

    public Medicine() {
    }


    public Medicine(String medicine_name, String short_word,String amount, String city, String customer_name ) {
        this.amount = amount;
        this.city = city;
        this.customer_name = customer_name;
        this.medicine_name = medicine_name;
        this.short_word = short_word;
    }



    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }
    public String getMedicine_name() {
        return medicine_name;
    }

    public void setMedicine_name(String medicine_name) {
        this.medicine_name = medicine_name;
    }

    public String getShort_word() {
        return short_word;
    }

    public void setShort_word(String short_word) {
        this.short_word = short_word;
    }
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCustomer_name() {
        return customer_name;
    }


}